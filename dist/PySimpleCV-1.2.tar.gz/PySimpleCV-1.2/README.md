# PySimpleCV
Graphical user interface for ploting CV, calculate jpa, jpc, reversibility, etc.

Currently support VersaStudio (.par), .csv, and .txt.
For .csv and .txt, first column must be voltage and second column is current.
![PySimpleCV](https://github.com/kevinsmia1939/PySimpleCV/blob/main/screenshot.png?raw=true)
